#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const FRAME_MAP = new Map([[5, 141], [10, 260], [15, 379]]);
const MODES = new Set(['I2VA', 'FL2VA', 'Ref2VA']);
const AUDIO_MODES = new Set(['drive-audio', 'reference-audio', 'no-audio']);

const fail = (message) => {
  console.error(`INVALID: ${message}`);
  process.exitCode = 1;
};

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

const parseClock = (value) => {
  const match = /^(\d{2,}):(\d{2})(?:\.(\d{1,3}))?$/.exec(value.trim());
  if (!match) return Number.NaN;
  return Number(match[1]) * 60 + Number(match[2]) + Number(`0.${match[3] ?? 0}`);
};

const parseRange = (value) => {
  if (typeof value !== 'string') return null;
  const parts = value.split(/\s*-\s*/);
  if (parts.length !== 2) return null;
  const start = parseClock(parts[0]);
  const end = parseClock(parts[1]);
  return Number.isFinite(start) && Number.isFinite(end) && end > start ? { start, end } : null;
};

const file = process.argv[2];
if (!file) {
  console.error('Usage: node validate_storyboard.mjs <project.json> [--legacy-compatible]');
  process.exit(2);
}

const legacyCompatible = process.argv.includes('--legacy-compatible');
let parsed;
try {
  parsed = JSON.parse(await readFile(resolve(file), 'utf8'));
} catch (error) {
  console.error(`INVALID: cannot read JSON: ${error.message}`);
  process.exit(1);
}

const project = parsed?.schema === 'mv-maker-project' ? parsed.project : parsed;
if (!isObject(project)) {
  fail('project must be an object');
} else {
  if (typeof project.proposal_id !== 'number') fail('proposal_id must be a number');
  if (typeof project.direction_name !== 'string' || !project.direction_name.trim()) fail('direction_name is required');
  if (!Array.isArray(project.characters)) fail('characters must be an array (it may be empty)');
  if (!Array.isArray(project.storyboard) || project.storyboard.length === 0) fail('storyboard must be a non-empty array');

  if (!legacyCompatible) {
    const plan = project.director_plan;
    if (!isObject(plan)) fail('director_plan is required in strict mode');
    else {
      for (const field of ['source_type', 'content_form', 'model', 'aspect_ratio', 'style_name', 'style_rationale', 'narrative_strategy', 'source_coverage_note']) {
        if (typeof plan[field] !== 'string' || !plan[field].trim()) fail(`director_plan.${field} is required`);
      }
      if (!['music_video', 'short_drama', 'promo'].includes(plan.content_form)) fail('director_plan.content_form is invalid');
      if (!Number.isFinite(plan.total_duration_seconds) || plan.total_duration_seconds <= 0) fail('director_plan.total_duration_seconds must be positive');
      if (!Array.isArray(plan.allowed_clip_durations_seconds) || plan.allowed_clip_durations_seconds.some((v) => !FRAME_MAP.has(v))) {
        fail('director_plan.allowed_clip_durations_seconds may contain only 5, 10, and 15');
      }
    }
  }

  let previousEnd = 0;
  let computedDuration = 0;
  let shotCount = 0;
  for (const [segmentIndex, segment] of (project.storyboard ?? []).entries()) {
    if (!isObject(segment) || typeof segment.segment_id !== 'number' || !Array.isArray(segment.mvinfo)) {
      fail(`storyboard[${segmentIndex}] is invalid`);
      continue;
    }
    for (const [shotIndex, shot] of segment.mvinfo.entries()) {
      const at = `storyboard[${segmentIndex}].mvinfo[${shotIndex}]`;
      shotCount += 1;
      const range = parseRange(shot.timestamp);
      if (!range) fail(`${at}.timestamp is invalid`);
      else {
        if (Math.abs(range.start - previousEnd) > 0.001) fail(`${at}.timestamp is not contiguous`);
        previousEnd = range.end;
      }

      if (legacyCompatible && !shot.generation_plan) continue;
      if (typeof shot.source_text !== 'string' || !shot.source_text.trim()) fail(`${at}.source_text is required`);
      if (typeof shot.video_prompt !== 'string' || !shot.video_prompt.trim()) fail(`${at}.video_prompt is required`);
      const plan = shot.generation_plan;
      if (!isObject(plan)) {
        fail(`${at}.generation_plan is required`);
        continue;
      }
      if (plan.model !== 'minimax-h3') fail(`${at}.generation_plan.model must be minimax-h3`);
      if (!MODES.has(plan.mode)) fail(`${at}.generation_plan.mode is invalid`);
      if (!FRAME_MAP.has(plan.duration_seconds) || FRAME_MAP.get(plan.duration_seconds) !== plan.duration_frames) {
        fail(`${at} has an invalid duration/frame pair`);
      }
      if (range && Math.abs((range.end - range.start) - plan.duration_seconds) > 0.001) {
        fail(`${at}.timestamp duration does not match generation_plan.duration_seconds`);
      }
      if (!AUDIO_MODES.has(plan.audio_mode)) fail(`${at}.generation_plan.audio_mode is invalid`);
      const refs = plan.reference_images ?? [];
      if (!Array.isArray(refs)) fail(`${at}.generation_plan.reference_images must be an array`);
      if (plan.mode === 'Ref2VA') {
        if (!Array.isArray(refs) || refs.length !== 2) fail(`${at} Ref2VA requires exactly two reference declarations`);
        for (const [refIndex, ref] of (Array.isArray(refs) ? refs : []).entries()) {
          if (!isObject(ref) || ref.label !== `<Picture ${refIndex + 1}>` || typeof ref.purpose !== 'string' || !ref.purpose.trim() || typeof ref.prompt !== 'string' || !ref.prompt.trim()) {
            fail(`${at}.generation_plan.reference_images[${refIndex}] is invalid`);
          }
        }
      } else if (Array.isArray(refs) && refs.length !== 0) {
        fail(`${at} ${plan.mode} must not declare Ref2VA reference images`);
      }
      if (plan.mode === 'FL2VA' && (typeof shot.last_frame_image_prompt !== 'string' || !shot.last_frame_image_prompt.trim())) {
        fail(`${at} FL2VA requires last_frame_image_prompt`);
      }
      if (plan.mode === 'I2VA' && shot.type !== 'Last_Frame_Continuity' && (typeof shot.image_prompt !== 'string' || !shot.image_prompt.trim())) {
        fail(`${at} I2VA New_Scene requires image_prompt`);
      }
      computedDuration += Number(plan.duration_seconds) || 0;
    }
  }

  if (shotCount === 0) fail('at least one shot is required');
  if (!legacyCompatible && isObject(project.director_plan) && Math.abs(computedDuration - project.director_plan.total_duration_seconds) > 0.001) {
    fail('director_plan.total_duration_seconds does not equal the sum of shot durations');
  }
}

if (!process.exitCode) console.log('VALID');

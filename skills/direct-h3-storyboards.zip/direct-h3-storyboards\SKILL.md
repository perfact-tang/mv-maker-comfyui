---
name: direct-h3-storyboards
description: Analyze lyrics, LRC files, novel or story excerpts, blog posts, explainers, and product copy as a director; choose music_video, short_drama, or promo; design characters, styles, narrative segments, and H3-ready shots; select I2VA, FL2VA, or Ref2VA per shot; and output an importable MV Maker project JSON. Use when the user asks for a storyboard, shot list, director treatment, H3 video plan, text-to-video adaptation, MV script, short-drama breakdown, promotional film plan, or a JSON accepted by MV Maker ComfyUI.
---

# Direct H3 Storyboards

Turn source text into a complete, executable director plan and MV Maker project JSON. Preserve source meaning before optimizing spectacle.

## Operating modes

- Default to **one-pass**: make defensible directing decisions and deliver the JSON without approval gates.
- Use **review-first** when the user asks to review, approve, discuss, or compare directions. Present only the proposed format, style, duration, character roster, and segment spine; create the final JSON after approval.
- Ask only for hard constraints that cannot be inferred safely: a required aspect ratio, supplied master-audio window, or a model limit that conflicts with the request.

## Required references

1. Read `references/directing-playbook.md` before analyzing or segmenting any source.
2. Read `references/project-schema.md` before constructing output.
3. Read `references/h3-routing.md` before choosing modes or writing H3 prompts.
4. Read `references/examples.md` only when the input classification or mode choice remains ambiguous.

## Workflow

### 1. Establish the contract

Determine source type, language, requested deliverable, aspect ratio, model, usable clip durations, audio ownership, and whether the user supplied timing. Default to MiniMax H3, landscape, and allowed durations `[5, 10, 15]` when unspecified.

### 2. Analyze as a director

Classify the production as `music_video`, `short_drama`, or `promo`. Use `promo` with subtype `editorial_explainer` for factual or knowledge-led articles. Select one coherent visual grammar and state why it fits the source.

Create atomic source units before adapting. Preserve every lyric line, causal story beat, necessary dialogue, claim, and supporting example. Never silently summarize away source units. For long inputs, work in batches and merge into one continuous timeline.

### 3. Build production anchors

Define only recurring, generation-relevant characters. Write each `description` in generation-ready English and lock age impression, build, face, hair, wardrobe, materials, signature objects, and do-not-change traits. Use an empty `characters` array when no character is needed.

Group source units into macro `storyboard` segments, then into executable `mvinfo` shots. Each shot must have one visual owner, one primary action, an explicit continuity handoff, source coverage, exact timing, and a generation plan.

### 4. Route every H3 shot

Choose exactly one mode per shot:

- `I2VA` for first-frame development, dialogue/performance, organic motion, or previous-tail continuation.
- `FL2VA` for an exact target composition, transformation result, product closure, match cut, or transition landing.
- `Ref2VA` when identity, wardrobe, product, brand, scene, or style references matter more than exact keyframes. Declare exactly two reference slots.

Map 5, 10, and 15 seconds to 141, 260, and 379 frames. Use the shortest duration that can express the action cleanly. Pad the final timeline to a 5-second boundary with an intentional hold or ambience; do not truncate source content.

### 5. Write model-ready prompts

Write T2I and H3 structural prose in English. Preserve dialogue, lyrics, and visible text in the original language. Use the exact H3 field order and timing rules in `references/h3-routing.md`; do not append loose style text after a completed H3 structure.

Populate `source_text` with the exact source excerpt. Keep `lyrics` for compatibility: use exact lyrics for music, required dialogue or narration for other forms, and `(No dialogue)` when the shot is visual-only.

### 6. Validate and deliver

Start from `assets/storyboard-template.json`, replace all placeholders, and write a complete `mv-maker-project` v3 JSON file. Run:

```text
node scripts/validate_storyboard.mjs <project.json>
```

Fix every error before delivery. In chat, report only the chosen form/style, total duration, segment and shot counts, mode distribution, and the output path. Do not paste a large JSON unless the user explicitly requests inline output.

## Non-H3 models

Treat H3 as the only fully implemented adapter. If another model is requested, preserve the director plan and schema, set that model identifier, and load an explicit model adapter supplied by the user or project. Do not pretend H3 task types are portable to another model.

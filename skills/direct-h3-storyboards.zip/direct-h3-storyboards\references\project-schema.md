# MV Maker Director JSON Contract

Output a complete `mv-maker-project` archive with `schema_version: 3`. The `project` object remains loadable as a legacy standalone script, but a full archive is preferred because it selects H3 and orientation automatically.

## Director additions

```json
{
  "director_plan": {
    "source_type": "lyrics | lrc | novel | story | blog | product_copy",
    "content_form": "music_video | short_drama | promo",
    "form_subtype": "editorial_explainer",
    "model": "minimax-h3",
    "aspect_ratio": "16:9",
    "total_duration_seconds": 15,
    "allowed_clip_durations_seconds": [5, 10, 15],
    "style_name": "...",
    "style_rationale": "...",
    "narrative_strategy": "...",
    "source_coverage_note": "All 6 source units mapped."
  }
}
```

`form_subtype` is optional. All other director fields are required for strict Skill output.

## Shot additions

```json
{
  "timestamp": "00:00 - 00:05",
  "type": "New_Scene",
  "source_text": "Exact source excerpt",
  "lyrics": "Exact lyric/dialogue or (No dialogue)",
  "image_prompt": "English first-frame prompt",
  "last_frame_image_prompt": "English target-frame prompt; FL2VA only",
  "video_prompt": "Complete H3 structured prompt",
  "generation_plan": {
    "model": "minimax-h3",
    "mode": "I2VA",
    "duration_seconds": 5,
    "duration_frames": 141,
    "audio_mode": "drive-audio",
    "reference_images": []
  }
}
```

Rules:

- `source_text`, `generation_plan`, and a non-empty H3 `video_prompt` are required in strict director output.
- `I2VA` uses zero reference declarations and needs `image_prompt` unless it is `Last_Frame_Continuity`.
- `FL2VA` uses zero reference declarations and needs `last_frame_image_prompt`.
- `Ref2VA` uses exactly two declarations:

```json
{
  "label": "<Picture 1>",
  "purpose": "character identity",
  "prompt": "<Picture 1> defines ...",
  "source_character": "Optional exact character name",
  "asset": {
    "dataUrl": "optional runtime value",
    "filename": "optional runtime value"
  }
}
```

- The pre-production JSON may omit `asset`; the app resolves `source_character` or requests an upload.
- `generated_assets.target_last_frame` is the planned FL2VA endpoint. `generated_assets.last_frame` is the actual extracted video tail used for continuity.
- Timestamps are contiguous; their duration equals `generation_plan.duration_seconds`.
- Duration/frame pairs are only `5/141`, `10/260`, and `15/379`.

## Compatibility

- `characters` is always an array and may be empty.
- Existing `lyrics` and `type` remain present.
- Old projects without `director_plan`, `source_text`, or `generation_plan` remain valid and use global H3 defaults.
- `generation_settings.h3` remains a legacy fallback and stores project-wide reference images only for old projects.
